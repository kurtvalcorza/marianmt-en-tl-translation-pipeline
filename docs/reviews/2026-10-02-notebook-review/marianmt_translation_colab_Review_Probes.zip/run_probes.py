"""Probes for the Framework v1 review of tutorials/marianmt_translation_colab.ipynb (row 42).

Direct execution is LOCAL CPU (Windows, repo .venv: torch 2.14.0+cpu, transformers 4.57.6, numpy 2.5.3),
install cell skipped via DIMER_NOTEBOOK_CI_PREINSTALLED=1, CUDA hidden, snapshot + corpus PRE-STAGED from the
local clone (the notebook re-verifies every digest). This is NOT a Colab run.

Usage: python run_probes.py <notebook.ipynb> <run_dir> <results.json>
P0 static checks; P1 default path (code cells 1..17); P2 documented experiment 'set NUM_BEAMS = 1' re-run from
Section 6a through Section 9; P3 BYOD re-run from Section 4 (BYOD_PATH, 400-row CSV) through Section 13;
P4 BYOD size contract (no model).
"""
import contextlib
import io
import json
import os
import re
import sys
import time
import traceback

os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

NB, RUN, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
nb = json.load(open(NB, encoding='utf-8'))
cells = nb['cells']
code = [''.join(c['source']) for c in cells if c['cell_type'] == 'code']
md = '\n'.join(''.join(c['source']) for c in cells if c['cell_type'] == 'markdown')
results = {'notebook': NB, 'env': 'local CPU, install skipped, snapshot+corpus pre-staged; not Colab'}


def save():
    with open(OUT, 'w', encoding='utf-8') as fh:
        json.dump(results, fh, indent=1, ensure_ascii=False, default=str)


# ---- P0 static ----
results['P0_static'] = {
    'cells': len(cells), 'code_cells': len(code),
    'metadata_dimer': nb['metadata'].get('dimer'),
    'cells_with_jupyter_source_hidden': sum(1 for c in cells if c.get('metadata', {}).get('jupyter', {}).get('source_hidden')),
    'cells_with_colab_cellView_form': sum(1 for c in cells if c.get('metadata', {}).get('cellView') == 'form'),
    'code_cells_starting_with_at_title': sum(1 for s in code if s.lstrip().startswith('# @title')),
    'opening_says_only_external_dependency_is_hub': 'Its only external dependencies are the pinned Python distributions and the Hugging Face Hub' in md,
    'prereq_says_external_access_hub_only': '**External access:** the Hugging Face Hub only' in md,
    'notebook_fetches_opus_host': 'object.pouta.csc.fi' in md,
    'env_var_DIMER_NOTEBOOK_CI_PREINSTALLED_in_markdown': 'DIMER_NOTEBOOK_CI_PREINSTALLED' in md,
    'MAX_EVAL_RECORDS_in_markdown': 'MAX_EVAL_RECORDS' in md or '2,000' in md,
    'byod_rerun_instruction': 'set `USE_BYOD = True` in Section 4 and re-run from that cell' in md,
    'experiment_rerun_instruction': 'Change **one** knob, re-run from its cell' in md,
}
save()

os.makedirs(RUN, exist_ok=True)
os.chdir(RUN)
ns = {'__name__': '__main__'}


def run_cell(k, label, overrides=None):
    """Execute code cell k (1-based) in the shared namespace; overrides replace form-field literal lines."""
    src = code[k - 1]
    for name, value in (overrides or {}).items():
        src, n = re.subn(rf'^{name} = .*$', f'{name} = {value!r}', src, flags=re.M)
        assert n == 1, f'form field {name} not found in code cell {k}'
    buf = io.StringIO()
    t = time.perf_counter()
    err = None
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            exec(compile(src, f'<code cell {k}>', 'exec'), ns)
        except BaseException:  # noqa: BLE001
            err = traceback.format_exc(limit=3)
    rec = {'cell': k, 'label': label, 'seconds': round(time.perf_counter() - t, 1), 'ok': err is None,
           'stdout_tail': buf.getvalue()[-2500:]}
    if err:
        rec['error'] = err[-1500:]
    return rec


# ---- P1 default path ----
p1 = []
for k in range(1, len(code) + 1):
    p1.append(run_cell(k, 'default'))
    results['P1_default'] = {'cells': p1}
    save()
    if not p1[-1]['ok']:
        break
results['P1_default']['summary'] = {
    'ok_cells': sum(r['ok'] for r in p1), 'of': len(code), 'seconds': round(sum(r['seconds'] for r in p1), 1),
    'comparison': ns.get('comparison'), 'changed_by_adaptation': ns.get('changed_by_adaptation'),
    'adapt_history_val_chrf': [round(h['val']['chrf'], 2) for h in ns['adapt_result']['history']] if 'adapt_result' in ns else None,
    'best_epoch': ns.get('adapt_result', {}).get('best_epoch'),
    'probe_cue_carried': sum(r['cue_carried_through'] for r in ns.get('probe_rows', [])),
    'reload_parity': ns.get('parity'), 'outputs': sorted(os.listdir('outputs')) if os.path.isdir('outputs') else None,
}
save()

# Ground truth: a fresh base pipeline (never adapted) for later comparisons.
Pipe = ns['MarianMTTranslationPipeline']
fresh = Pipe.from_pretrained(weights_dir=ns['WEIGHTS_DIR'])

# ---- P2 documented experiment: NUM_BEAMS = 1, re-run from Section 6a (code cell 8) through Section 9 (cell 12) ----
p2 = []
for k, ov in [(8, {'NUM_BEAMS': 1}), (9, None), (10, None), (11, None), (12, None)]:
    p2.append(run_cell(k, 'NUM_BEAMS=1 rerun', ov))
    results['P2_numbeams1_rerun'] = {'cells': p2}
    save()
true_frozen_greedy = fresh.evaluate(ns['test_records'], max_new_tokens=128, num_beams=1)
true_frozen_greedy_val = fresh.evaluate(ns['val_records'], max_new_tokens=128, num_beams=1)
results['P2_numbeams1_rerun']['summary'] = {
    'section7_labelled_frozen_chrf': round(ns['frozen_test']['chrf'], 2),
    'section7_frozen_test_reports_adapted_flag': ns['frozen_test'].get('adapted'),
    'true_frozen_greedy_test_chrf_fresh_base': round(true_frozen_greedy['chrf'], 2),
    'section8_epoch0_note': ns['adapt_result']['history'][0].get('note'),
    'section8_epoch0_val_chrf': round(ns['adapt_result']['history'][0]['val']['chrf'], 2),
    'true_frozen_greedy_val_chrf_fresh_base': round(true_frozen_greedy_val['chrf'], 2),
    'section9_comparison': ns.get('comparison'),
    'section9_ok': p2[-1]['ok'],
}
save()

# ---- P3 BYOD re-run from Section 4 (BYOD_PATH), NUM_BEAMS back to 4 ----
import csv  # noqa: E402

pairs = ns['read_corpus_pairs'](ns['corpus_bytes'])
used = {r['source'].lower() for part in ns['splits'].values() for r in part}
probes_src = {t.lower() for p in ns['PROBE_PAIRS'] for t in (p['original'], p['changed'])}
rows, seen = [], set()
for s, t in pairs:
    if 3 <= len(s) <= 200 and 3 <= len(t) <= 200 and s.lower() not in used and s.lower() not in seen and s.lower() not in probes_src:
        seen.add(s.lower())
        rows.append({'id': f'b{len(rows):04d}', 'source': s, 'target': t})
    if len(rows) == 400:
        break
os.makedirs('byod', exist_ok=True)
with open('byod/pairs.csv', 'w', encoding='utf-8', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=['id', 'source', 'target'])
    w.writeheader()
    w.writerows(rows)
p3 = []
ov_by_cell = {6: {'USE_BYOD': True, 'BYOD_PATH': 'byod/pairs.csv'}, 8: {'NUM_BEAMS': 4}}
for k in range(6, len(code) + 1):
    p3.append(run_cell(k, 'BYOD rerun from Section 4', ov_by_cell.get(k)))
    results['P3_byod_rerun'] = {'cells': p3}
    save()
    if not p3[-1]['ok']:
        break
true_frozen_byod = fresh.evaluate(ns['test_records'], max_new_tokens=128, num_beams=4)
true_frozen_byod_val = fresh.evaluate(ns['val_records'], max_new_tokens=128, num_beams=4)
results['P3_byod_rerun']['summary'] = {
    'ok_cells': sum(r['ok'] for r in p3), 'of': len(p3),
    'splits': ns.get('disjoint'),
    'section7_labelled_pretrained_chrf_on_byod_test': round(ns['frozen_test']['chrf'], 2),
    'section7_frozen_test_reports_adapted_flag': ns['frozen_test'].get('adapted'),
    'true_pretrained_chrf_on_byod_test_fresh_base': round(true_frozen_byod['chrf'], 2),
    'section8_epoch0_note': ns['adapt_result']['history'][0].get('note'),
    'section8_epoch0_val_chrf': round(ns['adapt_result']['history'][0]['val']['chrf'], 2),
    'true_pretrained_val_chrf_fresh_base': round(true_frozen_byod_val['chrf'], 2),
    'comparison': ns.get('comparison'), 'changed_by_adaptation': ns.get('changed_by_adaptation'),
    'new_sentences_sample_kind': ns.get('new_report', {}).get('sample_kind') if isinstance(ns.get('new_report'), dict) else None,
    'new_records_are_test_rows': [r['source'] for r in ns.get('new_records', [])] == [r['source'] for r in ns['test_records'][:6]],
    'reload_parity': ns.get('parity'),
}
save()

# ---- P4 BYOD size contract (no model) ----
p4 = {}
split_dataset, validate_dataset = ns['split_dataset'], ns['validate_dataset']
for n in (8, 12, 13):
    recs = [{'id': f'r{i}', 'source': f'Sentence number {i} here.', 'target': f'Pangungusap {i}.'} for i in range(n)]
    try:
        sp = split_dataset(recs, seed=42)
        p4[f'n={n}'] = {k: len(v) for k, v in sp.items()}
    except ValueError as exc:
        p4[f'n={n}'] = f'ValueError: {exc}'
recs = [{'id': f'r{i}', 'source': f'Sentence number {i} here.', 'target': f'Pangungusap {i}.'} for i in range(12000)]
sp = split_dataset(recs, seed=42)
p4['n=12000_split'] = {k: len(v) for k, v in sp.items()}
try:
    validate_dataset(sp['test'], min_records=1, max_records=ns['MAX_EVAL_RECORDS'])
    p4['n=12000_test_eval_ceiling'] = 'accepted'
except ValueError as exc:
    p4['n=12000_test_eval_ceiling'] = f'ValueError (raised in Section 7 evaluate, after model load): {exc}'
results['P4_byod_size_contract'] = p4
save()
print('done')
